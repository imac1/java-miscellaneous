import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class ApplicationTest {
@Test
    public void hiekkalaatikkoVihreakti() {
        assertTrue(true);
    }
}
