#include<conio.h>
#include<stdio.h>

#define NOGRADEYET 0
#define ABSENT -1

typedef struct {
	unsigned int nrm;
	char nume[30];
	unsigned char ans;
	unsigned int grupa;
	char fac[6];
	char note[20];
	unsigned char is; //indicator stare

}STUDENT;

void main()
{
	FILE* f;
	STUDENT x;
	int nrart, cheie, a, i;
	char numefr[20] = "..\\SR.dat"; //folerul parent

	f = fopen(numefr, "wb+");
	if (!f)
		printf("\nNu se poate deschide");
	else
	{
		printf("\nNumar matricol: "); scanf("%d", &cheie);
		while (!feof(stdin))  //while(cheie!=-1)
		{
			fseek(f, 0, 2);
			nrart = ftell(f) / sizeof(STUDENT);
			if (cheie >= nrart)	//daca caut o cheie  care nu e in fisier
			{
				x.is = 0;
				for (i = nrart; i <= cheie; i++)
					fwrite(&x, sizeof(STUDENT), 1, f);
			}
			fseek(f, cheie*sizeof(STUDENT), 0); //pozitionez pointer
			fread(&x, sizeof(STUDENT), 1, f);		 //verific daca nu am student cu cheie
			if (x.is == 1) //  1=scris deja	la cheia mentionata 0=liber de scris
				printf("\nCheie duplicata: %d", cheie);
			else
			{
				printf("\nNume si prenume: "); fflush(stdin); gets(x.nume);
				printf("\nAn de studiu: "); scanf("%d", &a); x.ans = a; //4 octeti --> 1 octet

				printf("Grupa: "); scanf("%d", &x.grupa);
				printf(" Faculatea (max 5): "); fflush(stdin); gets(x.fac);
				for (i = 0; i < 20; i++)
				{
					x.note[i] = NOGRADEYET;

				}

				x.nrm = cheie;
				x.is = 1;
				fseek(f, cheie*sizeof(STUDENT), 0);	  //repozitionez pointer
				fwrite(&x, sizeof(STUDENT), 1, f);	   //scriu studentul
			}
			printf("\Numar matr: "); scanf("%d", &cheie);
		}
		fclose(f);
		printf("\n\nAm creat fisierul relativ %s", numefr);

	}
	printf("\n Gata apasa o tasta");
	getch();

}