#include<conio.h>
#include<stdio.h>

#define NOGRADEYET 0
#define ABSENT -1

typedef struct {
	unsigned int nrm;
	char nume[30];
	unsigned char ans;
	unsigned int grupa;
	char fac[6];
	char note[20];
	unsigned char is; //indicator stare

}STUDENT;

void main()
{
	FILE *f, *g;
	STUDENT x;
	char numefr[20] = "..\\SR.dat";
	char numeft[20] = "..\\Lista1025.txt"; \
		int nrcrt;
	f = fopen(numefr, "rb");
	if (!f)
		printf("\nNu se poate desch");
	else
	{
		g = fopen(numeft, "wt");
		fprintf(g, "\t\tLista studentilor");
		fprintf(g, "\n\nNrcrt nrmat %-29s fac.  A Grupa", "Nume si prenume");
		nrcrt = 0;
		fread(&x, sizeof(STUDENT), 1, f);
		while (!feof(f))

		{
			if (x.is == 1)
				fprintf(g, "\n%5d %5d %-29s %-5s %d %5d", ++nrcrt, x.nrm, x.nume, x.fac, x.ans, x.grupa);
			fread(&x, sizeof(STUDENT), 1, f);
		}
		fclose(f);
		fclose(g);
		printf("\nLista se afla in fisierul %s",numeft );
	}
	printf("\n\nGata apasa o tasta");
	getch();
}