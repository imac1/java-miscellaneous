#include "DynamicLibraryMatrice\Matrice.h"
#include <stdio.h>
#include <conio.h>

void main()
{ double **a, **b, **c;
   int m,n;

   a = citire_matrice(&m);
   printf_s("\n Matricea A este: \n");
   afisare_matrice(a,m);

   b = aloca_matrice(m,m);
   b = citire_matrice(&m);
   printf_s("\n Matricea B este: \n");
   afisare_matrice(b,m);

   c = aloca_matrice(m,m);
   produs_mpn(a,b,m,c);
   printf_s("\n Matricea produs C  este: \n");
   afisare_matrice(c,m);

   a = dezalocare_matrice(a,m);
   
   copiaza(b,m,m,c);
   printf_s("\n Matricea noua C  este: \n");
   afisare_matrice(c,m);

  getch();
}
