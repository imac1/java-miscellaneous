#include <stdio.h>
#include <malloc.h>
#include "Matrice.h"
//citire matrice patrata cu alocare
    // I -
    // E - adresa matrice, dimensiune

double **citire_matrice(int *m)
{   int i,j;
   double **a;
     printf_s("\n Dimensiune : ") ;
     scanf_s("%d",m);
   a=new double*[*m];
   for(i=0;i<*m;i++)
         a[i]=new double[*m];
   for(i=0; i<*m;i++)
         for(j=0;j<*m;j++)
             { 
				 printf_s("a[%d,%d]= ",i,j);
                 scanf_s("%lf", &a[i][j] ) ;
             }
    return a;
}

//afisare matrice patrata
//I - adresa matrice, dimensiune
// E -

void afisare_matrice (double**a, int m)
{ 
	int i,j;
    for(i=0 ; i<m ; i++)
       { 
		   for(j=0 ; j<m ; j++)
             printf_s("%10.6lf ",a[i][j]);
         printf_s("\n");
       }
     printf_s("\n");
}

//alocare dinamica matrice
// I - nr. linii, nr. coloane
// E - adresa matricei

double **aloca_matrice (int m, int n)
{ double **a;
	a=new double*[m];
   for(int i=0;i<n;i++)
         a[i]=new double[m];
   return a;
}

//dezalocare matrice dinamica
//I - adresa matricei, nr. linii
// E - adresa matricei (NULL)

double** dezalocare_matrice (double **a, int m) 
{
	for(int i=0;i< m;i++)
		delete[] a[i];
	delete[] a;
	return a;
}

//produs matrice patrate de dimansiuni egale, prealocate
// I - a, b, n
// E � c

void produs_mpn(double** a, double **b, int n, double **c) 
{
	int sum;
	sum=0;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			{
				for(int k=0;k<n;k++)
                        sum = sum + a[i][k]*b[k][j];
                c[i][j] = sum;  
                sum = 0;
            }
    
	
}

//copiaza matrice prealocate
// I - a, m, n
// E � b

void copiaza(double** a, int m, int n, double** b)
{
	for( int i=0;i<m;i++)
		for(int j=0;j<n;j++)
			b[i][j]=a[i][j];  //copiaza matricea A in matricea B
	
}

