#include "ArrayFuncsLib.h"
#include<stdexcept>
#include<conio.h>
#include<stdio.h>

using namespace std;

void main()
{
	int a[] = {42 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,64 ,10 ,11 };
	int l;
	l=9;

	printf("%d ",ArrayFuncs::MyArrayFuncs::Scrie(a,l));
	printf("\n");
	printf("%d ",ArrayFuncs::MyArrayFuncs::Par(a,l));
	printf("\n");
	printf("%d ",ArrayFuncs::MyArrayFuncs::Scrie(a,l));


	getch();
}