namespace ArrayFuncs
{
	class MyArrayFuncs
	{
	
	public:	
		//Afisare
         static int Scrie(int a[], int l);

		//numere impare
		 static int Par(int a[], int l);
    };
}
