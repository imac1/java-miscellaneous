#include "ArrayFuncsLib.h"
#include<stdexcept>
#include<stdio.h>


using namespace std;

namespace ArrayFuncs    
{
	//Afisare vector de lungime l
	int MyArrayFuncs::Scrie(int a[],int l)
	{
		
			for(int i=0;i<l;i++)
				       printf("%d ", a[i]);
			return a[l];
	}

	//Afisare numere impare din vector
	int MyArrayFuncs::Par(int a[], int l)
	{
		int nr=0;
		for(int i=0; i<l; i++)
		{
			if(a[i]%2==0)
				{
					a[nr]=a[i];
				    nr++;
			    }
		}
		nr--;
		return MyArrayFuncs::Scrie(a,nr); 
	}

}