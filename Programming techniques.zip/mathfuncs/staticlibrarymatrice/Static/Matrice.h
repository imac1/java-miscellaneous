//alocare dinamica matrice
// I - nr. linii, nr. coloane
// E - adresa matricei

double **aloca_matrice (int m, int n) ;

//dezalocare matrice dinamica
//I - adresa matricei, nr. linii
// E - adresa matricei (NULL)

double** dezalocare_matrice (double **a, int m) ;

//produs matrice patrate de dimansiuni egale, prealocate
// I - a, b, n
// E � c

void produs_mpn (double** a, double **b, int n, double **c) ;

//copiaza matrice prealocate
// I - a, m, n
// E � b

void copiaza(double** a, int m, int n, double** b);

//citire matrice patrata cu alocare
// I -
// E - adresa matricei, dimensiune

double **citire_matrice(int *m);

//afisare matrice patrata
//I - adresa matrice, dimensiune
// E -
void afisare_matrice(double **a, int m);
